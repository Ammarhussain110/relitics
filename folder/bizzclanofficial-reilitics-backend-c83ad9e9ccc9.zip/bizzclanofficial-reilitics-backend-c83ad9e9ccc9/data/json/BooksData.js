const resourceData = [
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
  {
    noOfClicks: 22,
    noOfDownloads: 33,
    imageUrl: "./BooksImg.svg",

    title: "Only Words Book",
    resourceType: "book",
    resourceUrl: "https://google.com",
    AddedByAdmin: "620f421e8a7b15fb88751224",
  },
];

export { resourceData };
