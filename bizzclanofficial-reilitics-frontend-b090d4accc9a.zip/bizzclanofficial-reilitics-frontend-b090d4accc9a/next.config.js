module.exports = {
  reactStrictMode: true,
  swcMinify: false // it should be false by default
}
