import React from 'react'

const loginSlide = () => {
    return (
        <div>
            <div className='slidecolor'>
<p>bbbbbbbbbb</p>
            </div>
            
        </div>
    )
}

export default loginSlide
