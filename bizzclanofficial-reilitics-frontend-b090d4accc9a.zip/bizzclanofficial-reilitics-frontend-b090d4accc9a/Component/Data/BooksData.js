const BooksData = [
    {
        key: '1',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '2',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '3',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '4',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '5',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '6',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '7',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '8',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
    {
        key: '9',
        imgSrc: "./BooksImg.svg",
        title:"Only Words Book" ,
        authur:"One By Shane Ashby",
        cost:"$25",
    },
]

export default BooksData