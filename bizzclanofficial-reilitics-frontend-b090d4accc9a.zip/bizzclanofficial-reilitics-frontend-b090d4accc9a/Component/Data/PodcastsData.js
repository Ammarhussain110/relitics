const PodcastsData = [
    {
        key: '1',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '2',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '3',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '4',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '5',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '6',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '7',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '8',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
    {
        key: '9',
        imgSrc: "./PodcastsImg.svg",
        title:"Only Words Book" ,
        showBy:"Ask The Mentor"
    },
]

export default PodcastsData