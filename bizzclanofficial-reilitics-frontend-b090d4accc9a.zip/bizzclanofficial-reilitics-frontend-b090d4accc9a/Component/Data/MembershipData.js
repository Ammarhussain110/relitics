const Membership=[
    {
        id: 1,
        price: '50 USD',
        status: true,
        date: "28, june 2021"
    },
  
]
export default Membership