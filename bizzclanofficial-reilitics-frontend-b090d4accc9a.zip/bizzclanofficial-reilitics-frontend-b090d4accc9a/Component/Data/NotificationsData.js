

const NotificationsData = 
    {
        date: {
            Today: [
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "1You Account is approved by the admin. You can customise your Profile here"
                },
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "2You Account is approved by the admin. You can customise your Profile here"
                },
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "3You Account is approved by the admin. You can customise your Profile here"
                },
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "4You Account is approved by the admin. You can customise your Profile here"
                },
            ],
            Yesterday: [
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "11You Account is approved by the admin. You can customise your Profile here"
                },
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "22You Account is approved by the admin. You can customise your Profile here"
                },
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "33You Account is approved by the admin. You can customise your Profile here"
                },
                {
                    img: './notificationImg.png',
                    altImg: "Profile",
                    text: "44You Account is approved by the admin. You can customise your Profile here"
                },
            ]
        },
    }

export default NotificationsData;























{
    //   [
    //     {
    //         UTC: "1408648665",
    //         list: [
    //           {
    //             img: './notificationImg.png',
    //             content: "You Account is approved by the admin. You can customise your Profile here",
    //             altImg: "Profile",
    //             timestamp: "3PM"
    //           }
    //         ]
    //       },
    //     {
    //         UTC: "1408648665",
    //         list: [
    //           {
    //             img: './notificationImg.png',
    //             content: "You Account is approved by the admin. You can customise your Profile here",
    //             altImg: "Profile",
    //             timestamp: "1PM"
    //           }
    //         ]
    //       },
    //     {
    //         UTC: "1408648665",
    //         list: [
    //           {
    //             img: './notificationImg.png',
    //             content: "You Account is approved by the admin. You can customise your Profile here",
    //             altImg: "Profile",
    //             timestamp: "1PM"
    //           }
    //         ]
    //       },
    // ]
}