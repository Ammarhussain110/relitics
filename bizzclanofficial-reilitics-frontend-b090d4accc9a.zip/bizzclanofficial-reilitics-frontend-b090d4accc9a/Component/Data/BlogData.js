const blogDate = new Date (2022, 1, 8)
const blogData = [
    {
        id: 1,
        title: "1 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_2",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 2,
        title: "2 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Realstate",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 3,
        title: "3 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_2",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 4,
        title: "4 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Realstate",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 5,
        title: "5 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_2",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 6,
        title: "6 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Realstate",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 7,
        title: "7 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_2",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 8,
        title: "8 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Realstate",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 9,
        title: "9 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_2",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 10,
        title: "10 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Realstate",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 11,
        title: "11 which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_2",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: "Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 12,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 13,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 14,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 15,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 16,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 17,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 18,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Uncategory_1",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
    {
        id: 19,
        title: "which imac i should buy?",
        date: blogDate.toDateString(),
        category: "Realstate",
        cata: 'Blog',
        image: "/Mask Group 138.png",
        heading: "1Lorem Ipsum is simply dummy text of the printing ",
        description: " 12 Lorem Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        data: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    },
]


export default blogData

export function getEventById(id) {
    return blogData.find(x => x.id == id);
}
export function getEventByCategory(category) {
    return blogData.filter(x => x.category == category);
}