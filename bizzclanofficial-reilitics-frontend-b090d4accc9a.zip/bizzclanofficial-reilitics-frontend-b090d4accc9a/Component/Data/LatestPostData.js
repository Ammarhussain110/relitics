const LatestPost=[
    {
        id: 1,
        date: Date,
        title: "lorem ipsum is dummy text to use in diffrent places"
    },
    {
        id: 3,
        date: Date,
        title: "lorem ipsum is dummy text to use in diffrent places"
    },
    {
        id: 3,
        date: Date,
        title: "lorem ipsum is dummy text to use in diffrent places"
    },
    {
        id: 4,
        date: Date,
        title: "lorem ipsum is dummy text to use in diffrent places"
    },
]
export default LatestPost