const PaymentData = [
    {
        membership: "Free Membership",
        membershipprice: "0 USD",
        tax: "0 USD",
        total: "USD 0"

    }
]
export default PaymentData