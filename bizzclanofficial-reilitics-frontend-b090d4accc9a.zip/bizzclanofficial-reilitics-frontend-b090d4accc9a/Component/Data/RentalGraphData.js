const RentalGraphData = [
    {
        year:'2018',
        value: '18%'
    },
    {
        year:'2019',
        value: '19%'
    },
    {
        year:'2020',
        value: '20%'
    },
    {
        year:'2021',
        value: '21%'
    },
    {
        year:'2022',
        value: '22%'
    }
  ]
export default RentalGraphData