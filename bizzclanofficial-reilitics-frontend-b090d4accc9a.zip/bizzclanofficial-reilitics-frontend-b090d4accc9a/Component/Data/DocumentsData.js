const DocumnetsData = [
    {
        key: '1',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '2',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '3',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '4',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '5',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '6',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '7',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '8',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
    {
        key: '9',
        imgSrc: "./pdffileIcon.svg",
        fileName:"File Name.Pdf" ,
    },
]

export default DocumnetsData