import Navbar from "../Component/Navbar"
import HomePage from "./Home"
import Foter from "../Component/Footer"
export default function Home() {
  return (
    <div >
     <Navbar />
     <HomePage />
     <Foter />
    </div>
  )
}
